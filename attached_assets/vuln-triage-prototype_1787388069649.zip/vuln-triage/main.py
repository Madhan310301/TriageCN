#!/usr/bin/env python3
"""
Personalised Vulnerability Triage — CLI entry point.

Usage:
  python main.py --list-profiles
  python main.py --profile riverside-university
  python main.py --all                      # runs every profile, writes output/report.html

Add a brand-new profile at demo time: paste it into data/profiles.json (same schema)
and rerun --profile <its id> or --all. No code changes required.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.pipeline import load_vulnerabilities, load_profiles, load_aliases, run_for_profile, find_profile
from src.report_html import build_html_report

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")


def print_report(result: dict) -> None:
    print(f"\n{'=' * 70}\n{result['profile_name']}  ({result['profile_id']})\n{'=' * 70}")
    if not result["top5"]:
        print(f"\n{result['message']}\n")
    else:
        for i, card in enumerate(result["top5"], 1):
            b = card["score_breakdown"]
            print(f"\n#{i}  [{card['priority_band']}]  {card['cve_id']}  (score {b['total']})")
            print(f"    {card['title']}")
            print(f"    Score breakdown: kev={b['kev']} epss={b['epss']} exposure={b['exposure']} "
                  f"importance={b['importance']} cvss={b['cvss']} confidence_penalty={b['confidence_penalty']}")
            mc = card["matched_context"]
            print(f"    Matched: {mc['profile_technology']}  |  service={mc['service']}  "
                  f"exposure={mc['exposure']}  importance={mc['importance']}  match_layer={mc['match_layer']}")
            print(f"    Why it matters: {card['why_it_matters']}")
            print(f"    Potential impact: {card['potential_impact']}")
            print(f"    Next step: {card['next_step'].upper()}")
            print(f"    Confidence: {card['confidence']['level']} — {card['confidence']['reason']}")
            tr = card["traceability"]
            print(f"    Source: {tr['source']} (snapshot {tr['source_snapshot_date']}) — {tr['reference_url']}")

    print(f"\n--- What we checked and excluded (negative test, CVSS >= 9.0) ---")
    if not result["negative_test"]:
        print("  (no CVSS >= 9.0 findings were excluded or ranked low for this profile)")
    for n in result["negative_test"]:
        print(f"  {n['cve_id']} (CVSS {n['cvss_score']}, {n['vendor']}/{n['product']}) -> {n['status']}: {n['reason']}")
    print()


def main():
    ap = argparse.ArgumentParser(description="Personalised Vulnerability Triage")
    ap.add_argument("--profile", help="profile_id to run (see --list-profiles)")
    ap.add_argument("--all", action="store_true", help="run every profile and build the HTML report")
    ap.add_argument("--list-profiles", action="store_true")
    ap.add_argument("--data-dir", default=DATA_DIR)
    ap.add_argument("--json-out", help="write the raw result as JSON to this path")
    args = ap.parse_args()

    vuln_rows = load_vulnerabilities(os.path.join(args.data_dir, "vulnerabilities.csv"))
    profiles = load_profiles(os.path.join(args.data_dir, "profiles.json"))
    aliases = load_aliases(os.path.join(args.data_dir, "aliases.json"))

    if args.list_profiles:
        for p in profiles:
            print(f"{p['profile_id']:25s} {p['name']}")
        return

    if args.all:
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        results = [run_for_profile(vuln_rows, p, aliases) for p in profiles]
        for r in results:
            print_report(r)
        html_path = os.path.join(OUTPUT_DIR, "report.html")
        build_html_report(results, html_path)
        print(f"Wrote static report -> {html_path}")
        return

    if args.profile:
        profile = find_profile(profiles, args.profile)
        result = run_for_profile(vuln_rows, profile, aliases)
        print_report(result)
        if args.json_out:
            with open(args.json_out, "w") as f:
                json.dump(result, f, indent=2, default=str)
            print(f"Wrote JSON -> {args.json_out}")
        return

    ap.print_help()


if __name__ == "__main__":
    main()
