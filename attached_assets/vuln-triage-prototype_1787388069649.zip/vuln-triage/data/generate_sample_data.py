"""
Generates the sample/demo dataset for the Personalised Vulnerability Triage prototype.

IMPORTANT: The challenge brief says input files are "already provided" but none were
attached to this conversation. Every CVE ID, description, CVSS/EPSS/KEV value below is
SYNTHETIC — invented for this demo so the engine has something realistic to chew on.
None of it should be treated as real vulnerability intelligence. Swap this file for a
real NVD/KEV/EPSS export and the engine (src/) does not need to change at all.
"""
import csv
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SNAPSHOT_DATE = "2025-01-15"  # fictional static snapshot date, matches source_snapshot_date column

# cve_id, published_date, description, cvss_score, vendor, product,
# version_start, version_end, version_note, in_kev, epss_score, reference_url
VULNS = [
    # ---- Apache http_server family (tests alias table + version ranges) ----
    ["CVE-2024-58831", "2024-11-02", "Path traversal in mod_rewrite allows remote code execution via a crafted request", 9.8, "Apache Software Foundation", "httpd", "2.4.0", "2.4.53", "", True, 0.94],
    ["CVE-2024-58832", "2024-11-20", "Heap buffer overflow in mod_proxy when handling chunked responses", 8.1, "apache", "http_server", "2.4.54", "2.4.58", "", False, 0.42],
    ["CVE-2024-60455", "2024-12-01", "Information disclosure in server-status handler when misconfigured", 4.3, "Apache", "HTTP Server", "2.4.0", "2.4.60", "", False, 0.05],
    ["CVE-2024-60901", "2024-12-10", "Request splitting in mod_http2 leading to cache poisoning", 8.6, "Apache Software Foundation", "Apache HTTP Server", "2.4.40", "2.4.51", "", False, 0.44],

    # ---- WordPress family (tests alias table 'wp' -> wordpress) ----
    ["CVE-2024-58910", "2024-11-05", "Authentication bypass in the REST API allows unauthenticated post edits", 7.5, "WordPress", "wordpress", "6.0", "6.1.1", "", True, 0.81],
    ["CVE-2024-60502", "2024-12-15", "Stored XSS in the comment moderation screen", 6.1, "WordPress Foundation", "WordPress", "5.0", "6.3", "", False, 0.15],
    ["CVE-2024-61002", "2024-12-22", "Privilege escalation via crafted XML-RPC payload", 6.8, "wp", "wp", "6.0", "6.4", "", False, 0.22],

    # ---- OpenSSH family (tests clean version exclusion) ----
    ["CVE-2024-59102", "2024-11-08", "Pre-authentication race condition leads to remote code execution", 9.8, "OpenSSH", "openssh", "8.5", "8.9", "", True, 0.97],
    ["CVE-2024-59187", "2024-11-12", "Malformed packet causes daemon crash (denial of service)", 5.3, "openssh", "openssh", "9.0", "9.3", "", False, 0.11],
    ["CVE-2024-60820", "2024-12-18", "Signature verification bypass in certificate-based auth", 7.8, "OpenBSD", "OpenSSH", "8.0", "8.9", "", False, 0.30],
    ["CVE-2024-61500", "2024-12-28", "Legacy key-exchange downgrade allows session hijacking on old builds", 9.1, "OpenSSH", "openssh", "6.0", "7.9", "", False, 0.08],

    # ---- Microsoft SQL Server / Windows Server (tests NEEDS_VERIFICATION + version excl.) ----
    ["CVE-2023-49044", "2023-10-10", "Deserialization of untrusted data allows remote code execution", 9.8, "Microsoft", "SQL Server", "", "", "Affects all versions prior to the October 2023 cumulative update unless that CU has been applied", True, 0.90],
    ["CVE-2024-60600", "2024-12-05", "Information disclosure via verbose error messages", 5.9, "Microsoft", "SQL Server", "2016", "2019", "", False, 0.09],
    ["CVE-2024-61300", "2024-12-30", "Elevation of privilege in the SQL Agent service", 8.2, "Microsoft Corp", "SQL Server", "", "", "Only affects instances without cumulative update 5 applied", False, 0.30],
    ["CVE-2023-40077", "2023-08-14", "Print spooler flaw allows local privilege escalation", 8.4, "Microsoft", "Windows Server", "2012", "2019", "", True, 0.77],
    ["CVE-2022-41040-D", "2022-09-30", "Legacy RCE in an unpatched IIS/SSRS component", 9.1, "Microsoft", "Windows Server", "2003", "2012", "", False, 0.05],

    # ---- nginx (tests inclusive version boundaries) ----
    ["CVE-2024-60011", "2024-12-02", "HTTP request smuggling via inconsistent Content-Length handling", 7.2, "nginx", "nginx", "1.18.0", "1.20.0", "", False, 0.28],
    ["CVE-2024-60711", "2024-12-14", "TLS session resumption flaw allows session reuse across contexts", 6.5, "nginx", "nginx", "1.0", "1.18.0", "", False, 0.20],

    # ---- Node/Express (deliberately mis-typed vendor to force the fuzzy-match layer) ----
    ["CVE-2024-61600", "2025-01-03", "Prototype pollution in a popular JS web framework leads to remote code execution", 8.6, "Node JS", "Express", "4.0.0", "4.17.3", "", False, 0.95],

    # ---- Not used by either demo profile: feeds the required negative test ----
    ["CVE-2024-60099", "2024-12-03", "Unauthenticated RCE in the management interface of a network appliance", 9.8, "F5", "BIG-IP", "15.0", "17.1", "", True, 0.95],
    ["CVE-2024-60123", "2024-12-06", "Authentication bypass in the admin portal of a VPN appliance OS", 9.6, "Fortinet", "FortiOS", "6.0", "7.2", "", True, 0.90],
    ["CVE-2024-61455", "2025-01-05", "Remote code execution in a network device operating system", 9.9, "Cisco", "IOS", "15.0", "15.9", "", True, 0.98],
    ["CVE-2024-60321", "2024-12-09", "Deserialization flaw allows remote code execution", 9.0, "PHP Group", "PHP", "7.4", "8.1", "", False, 0.55],
    ["CVE-2024-60200", "2024-12-08", "Privilege escalation via crafted stored procedure", 8.8, "Oracle", "MySQL", "5.7", "8.0", "", False, 0.40],
    ["CVE-2024-61399", "2025-01-02", "Remote code execution via a malicious PDF document", 8.8, "Adobe", "Acrobat Reader", "2020", "2023", "", True, 0.60],
    ["CVE-2024-61155", "2024-12-31", "Local privilege escalation in a kernel driver", 7.0, "Linux Foundation", "Kernel", "5.4", "5.15", "", False, 0.18],
]

PROFILES = {
    "profiles": [
        {
            "profile_id": "riverside-university",
            "name": "Riverside State University",
            "sector": "education",
            "technologies": [
                {"vendor": "apache", "product": "http_server", "version": "2.4.49"},
                {"vendor": "wordpress", "product": "wordpress", "version": "6.1"},
                {"vendor": "openssh", "product": "openssh", "version": "8.7"},
                {"vendor": "nodejs", "product": "express", "version": "4.17.3"},
            ],
            "service": "student portal",
            "exposure": "internet-facing",
            "importance": "critical",
        },
        {
            "profile_id": "coastal-retail",
            "name": "Coastal Retail Co",
            "sector": "retail",
            "technologies": [
                {"vendor": "microsoft", "product": "sql_server", "version": "2019"},
                {"vendor": "microsoft", "product": "windows_server", "version": "2016"},
                {"vendor": "nginx", "product": "nginx", "version": "1.18.0"},
            ],
            "service": "internal inventory system",
            "exposure": "internal",
            "importance": "normal",
        },
    ]
}

ALIASES = {
    "_comment": "Every alias below is documented: raw form seen in CSV/profile data -> canonical name.",
    "vendors": {
        "microsoft corp": "microsoft",
        "microsoft corporation": "microsoft",
        "apache software foundation": "apache",
        "wordpress foundation": "wordpress",
        "openbsd": "openssh",           # OpenSSH is developed under the OpenBSD project umbrella
        "php group": "php",
        "linux foundation": "linux",
    },
    "products": {
        "httpd": "http_server",
        "apache http server": "http_server",
        "apache httpd": "http_server",
        "http server": "http_server",
        "wp": "wordpress",
        "sql server": "sql_server",
        "ms sql server": "sql_server",
        "mssql": "sql_server",
        "windows server": "windows_server",
        "win server": "windows_server",
        "kernel": "linux_kernel",
    },
}

GOLD_SET = [
    # profile_id, cve_id, expected_in_top5 (sanity-check sample only, not exhaustive)
    ["riverside-university", "CVE-2024-59102", "yes"],
    ["riverside-university", "CVE-2024-58831", "yes"],
    ["riverside-university", "CVE-2024-61500", "no"],
    ["coastal-retail", "CVE-2023-49044", "yes"],
    ["coastal-retail", "CVE-2022-41040-D", "no"],
]


def main():
    vuln_path = os.path.join(HERE, "vulnerabilities.csv")
    with open(vuln_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["cve_id", "published_date", "description", "cvss_score", "vendor", "product",
                    "version_start", "version_end", "version_note", "in_kev", "epss_score",
                    "reference_url", "source_snapshot_date"])
        for row in VULNS:
            cve_id = row[0]
            ref = f"https://nvd.nist.gov/vuln/detail/{cve_id}"
            w.writerow(row + [ref, SNAPSHOT_DATE])
    print(f"wrote {len(VULNS)} rows -> {vuln_path}")

    prof_path = os.path.join(HERE, "profiles.json")
    with open(prof_path, "w") as f:
        json.dump(PROFILES, f, indent=2)
    print(f"wrote {len(PROFILES['profiles'])} profiles -> {prof_path}")

    alias_path = os.path.join(HERE, "aliases.json")
    with open(alias_path, "w") as f:
        json.dump(ALIASES, f, indent=2)
    print(f"wrote alias table -> {alias_path}")

    gold_path = os.path.join(HERE, "gold_set.csv")
    with open(gold_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["profile_id", "cve_id", "expected_in_top5"])
        w.writerows(GOLD_SET)
    print(f"wrote gold set -> {gold_path}")


if __name__ == "__main__":
    main()
