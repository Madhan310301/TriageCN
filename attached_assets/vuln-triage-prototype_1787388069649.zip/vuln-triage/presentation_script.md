# 3-minute presentation script

**0:00–0:30 — Problem**
"Every org already has CVSS, EPSS, and KEV feeds telling them how scary a vulnerability
is in the abstract. Tools like CVE_Prioritizer and cvss-te do that well. But none of them
answer the question a security team actually asks Monday morning: *of the thousands of
CVEs published this month, which five touch MY stack, and why should I care today?* That
requires knowing the org's technologies, versions, exposure, and importance — nobody
ties scoring to the organisation. That's the gap we filled."

**0:30–1:15 — Approach**
"We built a 3-layer matching engine: exact canonical vendor/product matching with a
documented alias table, a fuzzy fallback for naming mismatches — used only when the exact
layer finds nothing, so it never silently returns empty — and honest version comparison
with three real outcomes: include-and-rank, include-but-verify, or excluded-with-a-
reason. Never a silent drop. On top of that sits a fully transparent additive score — KEV,
EPSS, exposure, importance, CVSS, confidence — with every term visible, never a bare
number."

**1:15–2:15 — Live two-profile demo**
"Here's Riverside State University — a critical, internet-facing student portal. Top 5:
[point to the KEV-flagged Apache and OpenSSH RCEs at URGENT]. Now watch the dropdown —
switch to Coastal Retail's internal inventory system, normal importance. Completely
different top 5, and note this SQL Server RCE is also KEV and CVSS 9.8, but it's flagged
'needs verification' because the CSV only gives us a version note, not a clean range — we
never guess a version match. Same engine, same code, two different organisations, two
different answers — because we told it to score for the organisation, not the CVE."

**2:15–2:45 — Negative test**
"Every profile view has this panel: What we checked and excluded. For Riverside, a
CVSS 9.9 Cisco IOS RCE is excluded — they don't run Cisco gear. And here's the version
one: OpenSSH 8.7 is installed, this CVE only affects 6.0 through 7.9 — cleanly excluded,
not by us assuming it's fine, by the version range actually saying so."

**2:45–3:00 — One known limitation**
"The fuzzy layer uses simple string similarity, not embeddings — good enough for typos
and naming variants, but it won't catch a completely different name for the same product.
That's a documented, deliberate trade-off for a 24-hour build; a local embedding model is
the natural next step and slots into the same interface."
