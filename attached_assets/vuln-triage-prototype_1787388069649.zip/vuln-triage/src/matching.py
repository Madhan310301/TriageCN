"""
Matching engine (Stage 1).

Given ONE profile and the full vulnerability list, decides — for every CVE row —
whether it applies to that profile, and how confidently.

Three honest outcomes per (cve, profile-technology) pair, never a silent drop:
  - INCLUDE_RANK              clean version data, installed version falls inside range
  - INCLUDE_NEEDS_VERIFICATION  version data missing/unparseable/notes-only, or profile
                                gave no version at all
  - EXCLUDE                   version data is clean and provably outside the range,
                               or the product plain isn't in this profile's stack

This module is intentionally profile-agnostic: it takes a profile dict as data, never
as a branch (`if profile_id == ...`). Run it against any profile matching the schema,
including one you've never seen, and it behaves the same way.
"""
from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from typing import Optional

from packaging.version import Version, InvalidVersion

FUZZY_THRESHOLD = 0.80


@dataclass
class MatchResult:
    cve_id: str
    match_type: str            # "INCLUDE_RANK" | "INCLUDE_NEEDS_VERIFICATION" | "EXCLUDE"
    layer: str                 # "exact" | "fuzzy" | "none"
    similarity: Optional[float]  # only set when layer == "fuzzy"
    matched_technology: Optional[dict]   # the profile technology this CVE was checked against
    exclusion_reason: Optional[str]
    row: dict                  # the original CSV row, for traceability


def canonicalize(vendor: str, product: str, aliases: dict) -> tuple[str, str]:
    """Lowercase + trim, then resolve through the alias table. Documented aliases only —
    no silent fuzzy guessing happens here, that's Layer 2's job."""
    v = (vendor or "").strip().lower()
    p = (product or "").strip().lower()
    v = aliases.get("vendors", {}).get(v, v)
    p = aliases.get("products", {}).get(p, p)
    return v, p


def _parse_version(raw: str) -> Optional[Version]:
    if raw is None or str(raw).strip() == "":
        return None
    try:
        return Version(str(raw).strip())
    except InvalidVersion:
        return None


def _version_outcome(installed_raw: str, start_raw: str, end_raw: str, note: str) -> tuple[str, Optional[str]]:
    """Returns (match_type, exclusion_reason_or_None) for the version dimension alone."""
    if note and str(note).strip():
        return "INCLUDE_NEEDS_VERIFICATION", None
    if not installed_raw or not str(installed_raw).strip():
        return "INCLUDE_NEEDS_VERIFICATION", None

    installed = _parse_version(installed_raw)
    start = _parse_version(start_raw)
    end = _parse_version(end_raw)

    if installed is None or (start is None and end is None):
        return "INCLUDE_NEEDS_VERIFICATION", None

    # Clean, parseable range: only exclude if we can PROVE it's outside.
    if start is not None and installed < start:
        return "EXCLUDE", f"installed version {installed_raw} is below the affected range ({start_raw}-{end_raw})"
    if end is not None and installed > end:
        return "EXCLUDE", f"installed version {installed_raw} is above the affected range ({start_raw}-{end_raw})"

    return "INCLUDE_RANK", None


def _fuzzy_ratio(a_vendor: str, a_product: str, b_vendor: str, b_product: str) -> float:
    a = f"{a_vendor} {a_product}".strip().lower()
    b = f"{b_vendor} {b_product}".strip().lower()
    return difflib.SequenceMatcher(None, a, b).ratio()


def match_profile(vuln_rows: list[dict], profile: dict, aliases: dict) -> list[MatchResult]:
    """Runs the full matching engine for one profile. Identical logic for any profile
    that follows the schema — no per-profile branching."""
    technologies = profile.get("technologies", [])

    # Pre-canonicalize every vuln row once.
    canon_rows = []
    for row in vuln_rows:
        cv, cp = canonicalize(row["vendor"], row["product"], aliases)
        canon_rows.append((cv, cp, row))

    results: list[MatchResult] = []
    claimed_cve_ids = set()  # rows already matched to some technology (any layer)

    for tech in technologies:
        t_vendor, t_product = canonicalize(tech["vendor"], tech["product"], aliases)

        # Layer 1: deterministic canonical match
        layer1_hits = [row for (cv, cp, row) in canon_rows if cv == t_vendor and cp == t_product]

        if layer1_hits:
            for row in layer1_hits:
                claimed_cve_ids.add(row["cve_id"])
                mtype, reason = _version_outcome(tech.get("version"), row["version_start"],
                                                   row["version_end"], row["version_note"])
                results.append(MatchResult(
                    cve_id=row["cve_id"], match_type=mtype, layer="exact", similarity=None,
                    matched_technology=tech, exclusion_reason=reason, row=row,
                ))
            continue  # Layer 2 is only for when Layer 1 found NOTHING for this technology

        # Layer 2: fuzzy fallback — only reached because Layer 1 found zero candidates
        for cv, cp, row in canon_rows:
            ratio = _fuzzy_ratio(t_vendor, t_product, row["vendor"], row["product"])
            if ratio >= FUZZY_THRESHOLD:
                claimed_cve_ids.add(row["cve_id"])
                mtype, reason = _version_outcome(tech.get("version"), row["version_start"],
                                                   row["version_end"], row["version_note"])
                results.append(MatchResult(
                    cve_id=row["cve_id"], match_type=mtype, layer="fuzzy", similarity=round(ratio, 3),
                    matched_technology=tech, exclusion_reason=reason, row=row,
                ))

    # Everything never claimed by any technology: explicitly excluded, never silently dropped.
    for cv, cp, row in canon_rows:
        if row["cve_id"] not in claimed_cve_ids:
            results.append(MatchResult(
                cve_id=row["cve_id"], match_type="EXCLUDE", layer="none", similarity=None,
                matched_technology=None,
                exclusion_reason=f"product '{row['vendor']} {row['product']}' is not in this profile's technology stack",
                row=row,
            ))

    return results
