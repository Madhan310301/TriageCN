"""
Scoring / ranking engine (Stage 2).

Every score is stored as a breakdown dict alongside the total — never collapsed to a
bare number. That breakdown is exactly what gets rendered to the user.
"""
from __future__ import annotations

IMPORTANCE_POINTS = {"critical": 15, "high": 10, "normal": 5}


def score_match(match, profile: dict) -> dict:
    """match is a matching.MatchResult. Returns the full breakdown dict."""
    row = match.row
    in_kev = str(row.get("in_kev", "")).strip().lower() == "true"
    epss = float(row.get("epss_score") or 0)
    cvss = float(row.get("cvss_score") or 0)
    exposure = profile.get("exposure", "internal")
    importance = profile.get("importance", "normal")

    kev_pts = 40 if in_kev else 0
    epss_pts = round(epss * 25)
    exposure_pts = 20 if exposure == "internet-facing" else 5
    importance_pts = IMPORTANCE_POINTS.get(importance, 5)
    cvss_pts = round((cvss / 10) * 10)

    confidence_penalty = 0
    if match.match_type == "INCLUDE_NEEDS_VERIFICATION":
        confidence_penalty += 5
    if match.layer == "fuzzy":
        confidence_penalty += 10  # a fuzzy product match is inherently less certain

    total = kev_pts + epss_pts + exposure_pts + importance_pts + cvss_pts - confidence_penalty

    return {
        "kev": kev_pts,
        "epss": epss_pts,
        "exposure": exposure_pts,
        "importance": importance_pts,
        "cvss": cvss_pts,
        "confidence_penalty": -confidence_penalty,
        "total": total,
    }


def priority_band(total: int) -> str:
    if total >= 70:
        return "URGENT"
    if total >= 50:
        return "HIGH"
    if total >= 30:
        return "MEDIUM"
    return "LOW"


def rank_top5(matches: list, profile: dict) -> list[dict]:
    """Scores every INCLUDE_RANK / INCLUDE_NEEDS_VERIFICATION match, dedupes by
    cve_id + product, sorts descending, returns the top 5 as {match, breakdown, band}."""
    included = [m for m in matches if m.match_type in ("INCLUDE_RANK", "INCLUDE_NEEDS_VERIFICATION")]

    deduped: dict[tuple, object] = {}
    for m in included:
        key = (m.cve_id, m.row["product"].strip().lower())
        # if duplicate, keep the one with the higher score
        if key not in deduped:
            deduped[key] = m
        else:
            existing_score = score_match(deduped[key], profile)["total"]
            new_score = score_match(m, profile)["total"]
            if new_score > existing_score:
                deduped[key] = m

    scored = []
    for m in deduped.values():
        breakdown = score_match(m, profile)
        scored.append({
            "match": m,
            "breakdown": breakdown,
            "band": priority_band(breakdown["total"]),
        })

    scored.sort(key=lambda x: x["breakdown"]["total"], reverse=True)
    return scored[:5]
