"""
Stage 4 — required negative test.

Finds every CVE with cvss_score >= 9.0 that did NOT make the top 5 for this profile,
and states exactly why: excluded outright (product not used / version out of range),
or matched but suppressed by low profile relevance (e.g. internal + normal-importance
service outscored by other findings).
"""
from __future__ import annotations

from .scoring import score_match, priority_band

SEVERE_THRESHOLD = 9.0


def find_excluded_severe(all_matches: list, top5: list[dict], profile: dict) -> list[dict]:
    top5_cve_ids = {entry["match"].cve_id for entry in top5}
    out = []

    for m in all_matches:
        cvss = float(m.row.get("cvss_score") or 0)
        if cvss < SEVERE_THRESHOLD:
            continue
        if m.cve_id in top5_cve_ids:
            continue  # made the cut, not a negative-test candidate

        if m.match_type == "EXCLUDE":
            reason = m.exclusion_reason
            status = "EXCLUDED"
            breakdown = None
            band = None
        else:
            # matched, but didn't make top 5 -> ranked low despite high CVSS
            breakdown = score_match(m, profile)
            band = priority_band(breakdown["total"])
            reason = (
                f"matched this profile's stack, but scored only {breakdown['total']} "
                f"({band}) once exposure ({profile.get('exposure')}) and importance "
                f"({profile.get('importance')}) were factored in — see breakdown"
            )
            status = "RANKED LOW"

        out.append({
            "cve_id": m.cve_id,
            "cvss_score": cvss,
            "status": status,
            "reason": reason,
            "breakdown": breakdown,
            "band": band,
            "description": m.row["description"],
            "vendor": m.row["vendor"],
            "product": m.row["product"],
        })

    out.sort(key=lambda x: x["cvss_score"], reverse=True)
    return out
