"""
Explanation layer (Stage 3).

Builds one card per top-5 item with every field the brief requires. The deterministic
string-template path below is the DEFAULT and works with zero API calls. An optional LLM
phrasing hook exists (see llm_phrase.py) but is only used if ANTHROPIC_API_KEY is set —
and even then it is only allowed to reorder/rephrase these same fields, never invent new
ones (see llm_phrase.py's system prompt for the exact constraint).
"""
from __future__ import annotations

CONSEQUENCE_HINTS = [
    ("remote code execution", "an attacker could run their own code on"),
    ("rce", "an attacker could run their own code on"),
    ("authentication bypass", "an attacker could log in without credentials to"),
    ("auth bypass", "an attacker could log in without credentials to"),
    ("privilege escalation", "a low-privilege user or attacker could gain admin-level control of"),
    ("elevation of privilege", "a low-privilege user or attacker could gain admin-level control of"),
    ("denial of service", "an attacker could crash or freeze"),
    ("information disclosure", "an attacker could read sensitive data from"),
    ("sql injection", "an attacker could manipulate the database behind"),
    ("sqli", "an attacker could manipulate the database behind"),
    ("cross-site scripting", "an attacker could run malicious scripts in users' browsers on"),
    ("xss", "an attacker could run malicious scripts in users' browsers on"),
    ("deserialization", "an attacker could run their own code on"),
    ("request smuggling", "an attacker could slip malicious requests past"),
]


def _consequence_phrase(description: str) -> str:
    d = description.lower()
    for key, phrase in CONSEQUENCE_HINTS:
        if key in d:
            return phrase
    return "this vulnerability could be used against"


def make_title(row: dict, profile: dict) -> str:
    service = profile.get("service", "your systems")
    consequence = _consequence_phrase(row["description"])
    in_kev = str(row.get("in_kev", "")).strip().lower() == "true"
    prefix = "Attackers are already exploiting a flaw" if in_kev else "A flaw exists"
    return f"{prefix} where {consequence} the software running your {service}"


def _confidence(match) -> tuple[str, str]:
    if match.layer == "exact" and match.match_type == "INCLUDE_RANK":
        return "High", "exact product match and the installed version falls cleanly inside the affected range"
    if match.layer == "fuzzy":
        return ("Medium" if (match.similarity or 0) >= 0.90 else "Low",
                f"product name matched by similarity ({match.similarity}), not an exact catalog entry — worth a manual check")
    if match.match_type == "INCLUDE_NEEDS_VERIFICATION":
        return "Medium", "the vendor data doesn't give a clean version range, so this needs a manual version check"
    return "Medium", "matched, but with some uncertainty in the underlying data"


def _next_step(match, band: str, profile: dict) -> str:
    if match.match_type == "INCLUDE_NEEDS_VERIFICATION":
        return "verify version"
    exposure = profile.get("exposure")
    if exposure == "internal" and band in ("HIGH", "MEDIUM"):
        return "restrict access"
    if band == "URGENT":
        return "escalate" if (exposure == "internet-facing" and profile.get("importance") == "critical") else "patch"
    if band == "HIGH":
        return "patch"
    if band == "MEDIUM":
        return "review vendor guidance"
    return "monitor"


def _why_it_matters(row: dict, breakdown: dict) -> str:
    parts = []
    if breakdown["kev"]:
        parts.append("it's on CISA's Known Exploited Vulnerabilities list, meaning it's being used in real attacks right now")
    epss = float(row.get("epss_score") or 0)
    if epss >= 0.5:
        parts.append(f"it has a high predicted exploitation likelihood (EPSS {epss:.0%})")
    elif epss > 0:
        parts.append(f"it has a modest predicted exploitation likelihood (EPSS {epss:.0%})")
    cvss = float(row.get("cvss_score") or 0)
    parts.append(f"its CVSS severity score is {cvss}/10")
    if not parts:
        return "It matched your technology stack."
    return "This matters because " + "; and ".join(parts) + "."


def _impact(row: dict) -> str:
    return f"Based on the vendor's own description: {row['description'].rstrip('.')}. No further consequence beyond what's stated here is assumed."


def build_card(entry: dict, profile: dict) -> dict:
    """entry is one item from scoring.rank_top5(): {"match", "breakdown", "band"}."""
    match = entry["match"]
    row = match.row
    breakdown = entry["breakdown"]
    band = entry["band"]
    confidence, confidence_reason = _confidence(match)
    tech = match.matched_technology or {}

    return {
        "cve_id": row["cve_id"],
        "priority_band": band,
        "score_breakdown": breakdown,
        "title": make_title(row, profile),
        "matched_context": {
            "profile_technology": f"{tech.get('vendor', '?')} {tech.get('product', '?')} {tech.get('version', '')}".strip(),
            "service": profile.get("service"),
            "exposure": profile.get("exposure"),
            "importance": profile.get("importance"),
            "match_layer": match.layer,
            "similarity": match.similarity,
        },
        "why_it_matters": _why_it_matters(row, breakdown),
        "potential_impact": _impact(row),
        "next_step": _next_step(match, band, profile),
        "confidence": {"level": confidence, "reason": confidence_reason},
        "traceability": {
            "source": "vulnerabilities.csv",
            "source_snapshot_date": row["source_snapshot_date"],
            "reference_url": row["reference_url"],
            "raw_row_vendor_product": f"{row['vendor']} / {row['product']}",
        },
    }


def build_cards(top5: list[dict], profile: dict) -> list[dict]:
    if not top5:
        return []
    return [build_card(entry, profile) for entry in top5]


NOTHING_MATCHED_MESSAGE = "Nothing matched this profile in the supplied data."
