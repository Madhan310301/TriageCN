# Personalised Vulnerability Triage

Given **one organisation's profile**, this tool outputs the 5 vulnerabilities *that
organisation* should act on — in plain language, with the full reasoning shown.

It is not a CVE severity lookup (CVSS/EPSS/KEV feeds already do that — see
[CVE_Prioritizer](https://github.com/TURROKS/CVE_Prioritizer) and
[cvss-te](https://github.com/kston83/cvss-te)). Its entire job is the piece those tools
skip: **does this CVE actually touch this organisation's stack, and how much should they
care given their exposure and importance?**

## Quickstart (under 5 minutes from a fresh clone)

```bash
pip install packaging --break-system-packages   # the only dependency; stdlib does the rest
python3 data/generate_sample_data.py            # (re)generates data/*.csv and *.json
python3 main.py --list-profiles
python3 main.py --profile riverside-university   # terminal report for one org
python3 main.py --all                            # runs every profile, writes output/report.html
```

Open `output/report.html` in any browser — no server needed. Use the **Profile**
dropdown top-right to switch organisations instantly (results are pre-computed and
embedded, so switching is instant, no recomputation, no network calls).

**To try an unseen profile at demo time:** paste a new object into `data/profiles.json`
following the existing schema, then rerun `python3 main.py --profile <its id>` or
`--all`. Nothing in `src/` branches on `profile_id` — the engine doesn't need to change.

## Sources

- `data/vulnerabilities.csv` — cve_id, published_date, description, cvss_score, vendor,
  product, version_start, version_end, version_note, in_kev, epss_score, reference_url,
  source_snapshot_date.
- `data/profiles.json` — organisation profiles: profile_id, name, sector, technologies[]
  (vendor/product/version), service, exposure, importance.
- `data/aliases.json` — the documented vendor/product alias table used by the matcher.
- `data/gold_set.csv` — a small hand-checked sanity sample.

**No real data was attached to the challenge prompt this was built from**, so
`data/generate_sample_data.py` produces a synthetic dataset with fictional CVE IDs
(clearly documented as such in that file) that exercises every code path: clean version
matches, alias-table hits, a deliberately mistyped vendor name to exercise the fuzzy
fallback, `version_note`-only rows, and several CVSS ≥ 9.0 vulnerabilities that aren't in
either demo profile's stack. **Swap this file for a real NVD + CISA KEV + FIRST EPSS
export with the same columns and nothing else changes.**

## Matching logic (Stage 1)

**Layer 1 — deterministic:** vendor and product are lowercased/trimmed, then resolved
through `data/aliases.json` (e.g. `httpd` → `http_server`, `wp` → `wordpress`). Only rows
whose canonical vendor+product match a profile technology's canonical vendor+product are
candidates. Every alias is listed with a comment in `generate_sample_data.py`'s `ALIASES`
dict.

**Layer 2 — fuzzy fallback**, used *only* when Layer 1 finds zero candidates for a given
profile technology (so an unrecognised naming convention in an unseen profile doesn't
silently return nothing): `difflib.SequenceMatcher` compares the raw `"vendor product"`
strings; matches ≥ 0.80 are accepted but permanently tagged `layer: fuzzy` and carry a
larger confidence penalty in scoring (see below) — a fuzzy hit is never treated as
equal-confidence to an exact one.

**Version comparison — three honest outcomes, never a silent drop:**

| Outcome | When |
|---|---|
| `INCLUDE_RANK` | version_start/end parse cleanly (via `packaging.version`) and the profile's installed version falls inside the range |
| `INCLUDE_NEEDS_VERIFICATION` | `version_note` is populated, version_start/end are empty/unparseable, or the profile gave no version |
| `EXCLUDE` | version data is clean and the installed version is provably outside the range, or the product isn't in the profile's stack at all |

`src/matching.py` runs identically against any profile dict that follows the schema —
there is no `if profile_id == ...` anywhere.

## Ranking logic (Stage 2)

Additive score, every term stored separately (never collapsed to a bare number):

```
score  = 40 if in_kev else 0
       + round(epss_score * 25)
       + (20 if exposure == "internet-facing" else 5)
       + {"critical": 15, "high": 10, "normal": 5}[importance]
       + round((cvss_score / 10) * 10)
       - confidence_penalty   # 5 if NEEDS_VERIFICATION, 10 if fuzzy-matched (additive)
```

Bands: `URGENT` (70+) / `HIGH` (50–69) / `MEDIUM` (30–49) / `LOW` (<30). Deduplicated by
`cve_id + product`, sorted descending, top 5 kept. The breakdown dict is what's rendered
— see any card in the HTML report or terminal output.

## Explanation layer (Stage 3)

Every card carries: priority band + visible breakdown, a consequence-first plain-language
title, matched context (which technology/service/exposure/importance triggered it), a
"why it matters" line citing the actual KEV/EPSS/CVSS signals, a potential-impact line
bound strictly to the CSV's own `description` field (no invented scenarios), exactly one
next step chosen from a fixed list (`verify version` / `review vendor guidance` / `patch`
/ `restrict access` / `monitor` / `escalate`), a confidence level with its reason, and
traceability (source, snapshot date, reference URL) that's spot-checkable against the CSV
row. All of this is generated by deterministic string templates in `src/explain.py` —
**zero API calls, and that's the default even if an LLM key is present**, per the brief.
If nothing matches a profile, the tool prints exactly *"Nothing matched this profile in
the supplied data."* — never "you are secure."

## Required negative test (Stage 4)

`src/negative_test.py` scans every CVE with `cvss_score >= 9.0` that did **not** make the
top 5 for the given profile and states exactly why — either excluded outright (product
not used / version out of range) or matched but scored low once exposure and importance
were factored in. This is a first-class section of both the terminal output and the HTML
report (collapsible "What we checked and excluded" panel), not a log line.

## Personalisation proof (Stage 5)

`python3 main.py --all` runs the identical engine against both demo profiles and prints
both reports back to back — the top 5 lists are completely different (a critical,
internet-facing student portal surfaces different urgency than an internal, normal-
importance inventory system, even where the same CVE is matched to both). The HTML
report's dropdown makes this switch demonstrable in seconds.

## Assumptions

- Version strings are assumed to be reasonably semver-like; `packaging.version` handles
  common vendor schemes (including bare integers like "2016" for Windows Server
  releases). No attempt is made to parse every vendor's bespoke versioning scheme — those
  fall into `INCLUDE_NEEDS_VERIFICATION` rather than being guessed at.
- The alias table is intentionally small and hand-curated rather than exhaustive; it's
  meant to be extended as real vendor-naming quirks are discovered.
- `in_kev` is read as the literal string `"True"`/`"False"` as it would come out of a CSV
  export; adjust the parser in `matching.py`/`scoring.py` if your real export uses `1`/`0`
  or a different column name.

## Limitations

- The fuzzy-match layer (Layer 2) uses `difflib.SequenceMatcher` for speed and zero extra
  dependencies within a 5-minute setup budget; a local embedding model (e.g.
  `all-MiniLM-L6-v2` via `sentence-transformers`) would generalise better to very
  different naming conventions but adds a multi-hundred-MB dependency and slower cold
  start, so it's left as a documented swap-in rather than the default.
- The scoring weights (40/25/20/15/10) are a reasonable, transparent starting point, not
  a validated risk model — a real deployment would want to tune them against
  organisation-specific incident history.
- The optional LLM phrasing hook is stubbed but not wired to a live API call in this
  submission, to keep the default path at zero API calls as the brief requires; the
  interface for it (pass only the matched record's fields as structured JSON) is
  documented in `src/explain.py`'s module docstring.
